import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Fallback para Flutter Web: os navegadores não permitem acessar diretórios
/// privados como arquivos comuns, então cada imagem fica em armazenamento local.
class FeedPhotoStore {
  static const String _prefix = 'feed_web:';
  final Map<String, Future<Uint8List?>> _cache = <String, Future<Uint8List?>>{};

  Future<String> saveImage(XFile image) async {
    final bytes = await image.readAsBytes();
    final preferences = await SharedPreferences.getInstance();
    final key = 'feed_image_${DateTime.now().microsecondsSinceEpoch}';
    await preferences.setString(key, base64Encode(bytes));
    _cache['$_prefix$key'] = Future<Uint8List?>.value(bytes);
    return '$_prefix$key';
  }

  Future<bool> exists(String path) async {
    if (!path.startsWith(_prefix)) return false;
    final preferences = await SharedPreferences.getInstance();
    return preferences.containsKey(path.substring(_prefix.length));
  }

  Future<Uint8List?> readImage(String path) {
    return _cache.putIfAbsent(path, () async {
      if (!path.startsWith(_prefix)) return null;
      final preferences = await SharedPreferences.getInstance();
      final encoded = preferences.getString(path.substring(_prefix.length));
      if (encoded == null) return null;
      try {
        return base64Decode(encoded);
      } catch (_) {
        return null;
      }
    });
  }

  Widget imageWidget(
    String path, {
    double? width,
    double? height,
    required BoxFit fit,
    required Widget fallback,
  }) {
    return FutureBuilder<Uint8List?>(
      future: readImage(path),
      builder: (context, snapshot) {
        if (snapshot.hasError) return fallback;
        if (!snapshot.hasData) {
          return SizedBox(
            width: width,
            height: height,
            child: const Center(child: CircularProgressIndicator()),
          );
        }
        return Image.memory(
          snapshot.data!,
          width: width,
          height: height,
          fit: fit,
          errorBuilder: (_, __, ___) => fallback,
        );
      },
    );
  }
}
