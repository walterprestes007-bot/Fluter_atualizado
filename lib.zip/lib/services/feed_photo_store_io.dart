import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

/// Armazena as fotos em documentos/fotos_feed, dentro do sandbox do app.
class FeedPhotoStore {
  Future<String> saveImage(XFile image) async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final photosDirectory = Directory(
      '${documentsDirectory.path}${Platform.pathSeparator}fotos_feed',
    );
    await photosDirectory.create(recursive: true);

    final extension = _safeImageExtension(image.name);
    final fileName = 'foto_${DateTime.now().microsecondsSinceEpoch}$extension';
    final savedFile = File(
      '${photosDirectory.path}${Platform.pathSeparator}$fileName',
    );
    await savedFile.writeAsBytes(await image.readAsBytes(), flush: true);
    return savedFile.path;
  }

  Future<bool> exists(String path) => File(path).exists();

  Future<Uint8List?> readImage(String path) async {
    try {
      return await File(path).readAsBytes();
    } catch (_) {
      return null;
    }
  }

  Widget imageWidget(
    String path, {
    double? width,
    double? height,
    required BoxFit fit,
    required Widget fallback,
  }) {
    return Image.file(
      File(path),
      width: width,
      height: height,
      fit: fit,
      errorBuilder: (_, __, ___) => fallback,
    );
  }

  String _safeImageExtension(String fileName) {
    final dot = fileName.lastIndexOf('.');
    if (dot >= 0) {
      final extension = fileName.substring(dot).toLowerCase();
      if (RegExp(r'^\.[a-z0-9]{1,8}$').hasMatch(extension)) {
        return extension;
      }
    }
    return '.jpg';
  }
}
