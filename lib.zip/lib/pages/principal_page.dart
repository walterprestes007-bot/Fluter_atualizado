import 'package:flutter/material.dart';

import 'cep_page.dart';
import 'cnpj_page.dart';
import 'dolar_page.dart';
import 'trabalho_page.dart';
import 'camera_gallery_page.dart';
import '../localizacao.dart';

class PrincipalPage extends StatelessWidget {
  const PrincipalPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text('Consulta Fácil'),

        backgroundColor: Colors.deepPurple,

        foregroundColor: Colors.white,
      ),

      drawer: Drawer(

        child: ListView(

          padding: EdgeInsets.zero,

          children: [

            const DrawerHeader(

              decoration: BoxDecoration(
                color: Colors.deepPurple,
              ),

              child: Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,

                children: [

                  Icon(
                    Icons.account_circle,
                    size: 70,
                    color: Colors.white,
                  ),

                  SizedBox(height: 10),

                  Text(
                    'Consulta Fácil',

                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                    ),
                  ),
                ],
              ),
            ),

            ListTile(
              leading: const Icon(Icons.location_on),

              title: const Text('Consultar CEP'),

              onTap: () {

                Navigator.push(
                  context,

                  MaterialPageRoute(
                    builder: (context) =>
                        const CepPage(),
                  ),
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.business),

              title: const Text('Consultar CNPJ'),

              onTap: () {

                Navigator.push(
                  context,

                  MaterialPageRoute(
                    builder: (context) =>
                        const CnpjPage(),
                  ),
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.attach_money),

              title: const Text('Cotação do Dólar'),

              onTap: () {

                Navigator.push(
                  context,

                  MaterialPageRoute(
                    builder: (context) =>
                        const DolarPage(),
                  ),
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.location_on),
              title: const Text('Minha Localização'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Localizacao(),
                  ),
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.work),

              title: const Text('Trabalho'),

              onTap: () {

                Navigator.push(
                  context,

                  MaterialPageRoute(
                    builder: (context) =>
                        const TrabalhoPage(),
                  ),
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.photo_camera_rounded),
              title: const Text('Câmera e Galeria'),
              subtitle: const Text('Tirar foto ou escolher imagem'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CameraGalleryPage(),
                  ),
                );
              },
            ),
          ],
        ),
      ),

      body: Center(

        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,

          children: [

            const Icon(
              Icons.waving_hand,
              size: 80,
              color: Colors.deepPurple,
            ),

            const SizedBox(height: 20),

            const Text(
              'Sejam Bem-Vindos!',

              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 40),

            ElevatedButton.icon(

              onPressed: () {

                Navigator.push(
                  context,

                  MaterialPageRoute(
                    builder: (context) =>
                        const CepPage(),
                  ),
                );
              },

              icon: const Icon(Icons.location_on),

              label:
                  const Text('Consultar CEP'),
            ),

            const SizedBox(height: 15),

            ElevatedButton.icon(

              onPressed: () {

                Navigator.push(
                  context,

                  MaterialPageRoute(
                    builder: (context) =>
                        const CnpjPage(),
                  ),
                );
              },

              icon: const Icon(Icons.business),

              label:
                  const Text('Consultar CNPJ'),
            ),

            const SizedBox(height: 15),

            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CameraGalleryPage(),
                  ),
                );
              },
              icon: const Icon(Icons.photo_camera_rounded),
              label: const Text('Câmera e Galeria'),
            ),
          ],
        ),
      ),
    );
  }
}