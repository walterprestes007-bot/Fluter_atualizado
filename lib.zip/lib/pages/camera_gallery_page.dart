import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

/// Tela para visualizar a câmera, tirar fotos e escolher imagens da galeria.
///
/// Ela é aberta a partir do menu principal e usa Navigator.pop normalmente
/// para retornar à tela anterior, sem substituir o fluxo de login do app.
class CameraGalleryPage extends StatefulWidget {
  const CameraGalleryPage({super.key});

  @override
  State<CameraGalleryPage> createState() => _CameraGalleryPageState();
}

class _CameraGalleryPageState extends State<CameraGalleryPage>
    with WidgetsBindingObserver {
  final ImagePicker _imagePicker = ImagePicker();

  CameraController? _cameraController;
  Uint8List? _imageBytes;

  bool _isInitializing = false;
  bool _isLoading = true;
  bool _isTakingPhoto = false;
  bool _isPickingImage = false;
  bool _reinitializeAfterCurrentOperation = false;
  String? _cameraError;

  bool get _cameraIsReady =>
      _cameraController != null &&
      _cameraController!.value.isInitialized &&
      _cameraError == null;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
  }

  /// Inicializa a câmera traseira (ou a primeira câmera disponível).
  Future<void> _initializeCamera() async {
    if (_isInitializing) {
      _reinitializeAfterCurrentOperation = true;
      return;
    }

    if (_cameraIsReady) return;

    _isInitializing = true;
    if (mounted) {
      setState(() {
        _isLoading = true;
        _cameraError = null;
      });
    }

    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        throw StateError('Nenhuma câmera foi encontrada neste dispositivo.');
      }

      final selectedCamera = cameras.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      final controller = CameraController(
        selectedCamera,
        ResolutionPreset.medium,
        enableAudio: false,
      );

      _cameraController = controller;
      await controller.initialize();

      // Se a tela foi fechada ou a câmera foi liberada durante a inicialização,
      // não mantenha um controlador que já não pertence à tela.
      if (!mounted || !identical(_cameraController, controller)) {
        // O dispose da tela ou a mudança de ciclo de vida já liberou a câmera.
        return;
      }
    } catch (error) {
      // Se a câmera foi liberada porque o app ficou em segundo plano, a falha
      // não deve ser exibida como erro definitivo: ela será aberta novamente.
      final lifecycleCancelled =
          _reinitializeAfterCurrentOperation && _cameraController == null;

      // Libera o controlador caso a inicialização tenha falhado no meio do processo.
      final failedController = _cameraController;
      _cameraController = null;
      if (failedController != null) {
        try {
          await failedController.dispose();
        } catch (_) {
          // O controlador pode já ter sido liberado pela mudança de ciclo de vida.
        }
      }

      if (mounted && !lifecycleCancelled) {
        setState(() => _cameraError = _cameraErrorMessage(error));
      }
    } finally {
      _isInitializing = false;
      if (mounted) {
        setState(() => _isLoading = false);
      }

      final shouldReinitialize =
          _reinitializeAfterCurrentOperation &&
          WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed &&
          mounted &&
          _cameraError == null;

      if (_reinitializeAfterCurrentOperation &&
          WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        _reinitializeAfterCurrentOperation = false;
      }

      if (shouldReinitialize) _initializeCamera();
    }
  }

  String _cameraErrorMessage(Object error) {
    if (error is CameraException) {
      switch (error.code) {
        case 'CameraAccessDenied':
        case 'CameraAccessDeniedWithoutPrompt':
          return 'O acesso à câmera foi negado. Permita o uso da câmera nas configurações do dispositivo.';
        case 'CameraAccessRestricted':
          return 'O acesso à câmera está restrito neste dispositivo.';
        default:
          return 'Não foi possível abrir a câmera. ${error.description ?? error.code}';
      }
    }

    if (error is StateError) return error.message.toString();
    return 'Não foi possível acessar a câmera. Verifique as permissões e tente novamente.';
  }

  /// Libera a câmera quando o app vai para segundo plano e a reabre ao voltar.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      final controller = _cameraController;
      _cameraController = null;
      if (_isInitializing) _reinitializeAfterCurrentOperation = true;
      controller?.dispose();
    } else if (state == AppLifecycleState.resumed &&
        _cameraController == null) {
      if (_isInitializing) {
        _reinitializeAfterCurrentOperation = true;
      } else {
        _initializeCamera();
      }
    }
  }

  /// Captura uma foto com a câmera ativa e a apresenta na tela.
  Future<void> _takePhoto() async {
    final controller = _cameraController;
    if (controller == null ||
        !controller.value.isInitialized ||
        _isTakingPhoto) {
      return;
    }

    setState(() => _isTakingPhoto = true);
    try {
      final photo = await controller.takePicture();
      final bytes = await photo.readAsBytes();
      if (!mounted) return;
      setState(() => _imageBytes = bytes);
    } catch (_) {
      if (mounted) {
        _showMessage('Não foi possível tirar a foto. Tente novamente.');
      }
    } finally {
      if (mounted) setState(() => _isTakingPhoto = false);
    }
  }

  /// Abre o seletor nativo do aparelho e carrega a imagem escolhida.
  Future<void> _openGallery() async {
    if (_isPickingImage) return;

    setState(() => _isPickingImage = true);
    try {
      final selectedImage = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
      );

      if (selectedImage == null) return; // O usuário cancelou a seleção.

      final bytes = await selectedImage.readAsBytes();
      if (!mounted) return;
      setState(() => _imageBytes = bytes);
    } catch (_) {
      if (mounted) {
        _showMessage('Não foi possível abrir a galeria. Verifique as permissões.');
      }
    } finally {
      if (mounted) setState(() => _isPickingImage = false);
    }
  }

  void _returnToCamera() {
    setState(() => _imageBytes = null);
    if (_cameraController == null && !_isInitializing) {
      _initializeCamera();
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cameraController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F5FC),
      appBar: AppBar(
        title: const Text('Câmera e Galeria'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Suas imagens',
                style: TextStyle(
                  color: Color(0xFF281943),
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                _imageBytes == null
                    ? 'Tire uma foto ou escolha uma imagem do celular.'
                    : 'Confira a imagem e, quando quiser, tire outra foto.',
                style: TextStyle(color: Colors.deepPurple.shade300),
              ),
              const SizedBox(height: 18),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.deepPurple.withValues(alpha: 0.12),
                        blurRadius: 18,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: _buildPreview(),
                ),
              ),
              const SizedBox(height: 20),
              if (_cameraError != null && _imageBytes == null)
                FilledButton.tonalIcon(
                  onPressed: _isLoading ? null : _initializeCamera,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Tentar abrir a câmera novamente'),
                ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _isLoading || _isTakingPhoto || _isPickingImage
                          ? null
                          : (_imageBytes == null ? _takePhoto : _returnToCamera),
                      icon: Icon(
                        _imageBytes == null
                            ? Icons.camera_alt_rounded
                            : Icons.refresh_rounded,
                      ),
                      label: Text(
                        _isTakingPhoto
                            ? 'Capturando...'
                            : (_imageBytes == null ? 'Tirar foto' : 'Nova foto'),
                      ),
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _isPickingImage || _isTakingPhoto
                          ? null
                          : _openGallery,
                      icon: _isPickingImage
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.photo_library_outlined),
                      label: const Text('Galeria'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.deepPurple,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        side: const BorderSide(color: Colors.deepPurple),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPreview() {
    if (_imageBytes != null) {
      return Image.memory(
        _imageBytes!,
        fit: BoxFit.contain,
        width: double.infinity,
        errorBuilder: (context, error, stackTrace) => const Center(
          child: Text(
            'Não foi possível exibir esta imagem.',
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Colors.white),
      );
    }

    if (_cameraError != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.no_photography_outlined,
                  color: Colors.white, size: 58),
              const SizedBox(height: 16),
              Text(
                _cameraError!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 15),
              ),
            ],
          ),
        ),
      );
    }

    final controller = _cameraController;
    if (controller == null || !controller.value.isInitialized) {
      return const Center(
        child: Text(
          'A câmera ainda não está disponível.',
          style: TextStyle(color: Colors.white),
        ),
      );
    }

    return Center(
      child: AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: CameraPreview(controller),
      ),
    );
  }
}
