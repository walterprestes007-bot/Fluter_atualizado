/// Implementação de armazenamento adequada a cada plataforma.
/// Em Android/iOS usa uma pasta privada de arquivos. No navegador, os bytes
/// ficam no armazenamento local do app porque navegadores não expõem pastas
/// do sistema de arquivos como diretórios comuns.
export 'feed_photo_store_stub.dart'
    if (dart.library.io) 'feed_photo_store_io.dart'
    if (dart.library.html) 'feed_photo_store_web.dart';
