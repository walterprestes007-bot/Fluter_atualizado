import 'package:flutter/material.dart';

import '../localizacao.dart';
import 'camera_gallery_page.dart';
import 'cep_page.dart';
import 'cnpj_page.dart';
import 'dolar_page.dart';
import 'feed_page.dart';
import 'trabalho_page.dart';

/// Tela principal do Consulta Fácil.
/// Mantém os atalhos e oferece navegação para a câmera/galeria e o feed.
class PrincipalPage extends StatelessWidget {
  const PrincipalPage({super.key});

  void _openPage(BuildContext context, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Consulta Fácil'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.account_circle, size: 70, color: Colors.white),
                  SizedBox(height: 10),
                  Text(
                    'Consulta Fácil',
                    style: TextStyle(color: Colors.white, fontSize: 22),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.location_on),
              title: const Text('Consultar CEP'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const CepPage());
              },
            ),
            ListTile(
              leading: const Icon(Icons.business),
              title: const Text('Consultar CNPJ'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const CnpjPage());
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Cotação do Dólar'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const DolarPage());
              },
            ),
            ListTile(
              leading: const Icon(Icons.my_location),
              title: const Text('Minha Localização'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const Localizacao());
              },
            ),
            ListTile(
              leading: const Icon(Icons.work),
              title: const Text('Trabalho'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const TrabalhoPage());
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera_rounded),
              title: const Text('Câmera e Galeria'),
              subtitle: const Text('Tirar foto ou escolher imagem'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const CameraGalleryPage());
              },
            ),
            ListTile(
              leading: const Icon(Icons.dynamic_feed_rounded),
              title: const Text('Feed Dinâmico'),
              subtitle: const Text('Fotos, curtidas e comentários'),
              onTap: () {
                Navigator.pop(context);
                _openPage(context, const FeedPage());
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.waving_hand,
                  size: 80,
                  color: Colors.deepPurple,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Sejam Bem-Vindos!',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 40),
                ElevatedButton.icon(
                  onPressed: () => _openPage(context, const CepPage()),
                  icon: const Icon(Icons.location_on),
                  label: const Text('Consultar CEP'),
                ),
                const SizedBox(height: 15),
                ElevatedButton.icon(
                  onPressed: () => _openPage(context, const CnpjPage()),
                  icon: const Icon(Icons.business),
                  label: const Text('Consultar CNPJ'),
                ),
                const SizedBox(height: 15),
                ElevatedButton.icon(
                  onPressed: () => _openPage(context, const CameraGalleryPage()),
                  icon: const Icon(Icons.photo_camera_rounded),
                  label: const Text('Câmera e Galeria'),
                ),
                const SizedBox(height: 15),
                ElevatedButton.icon(
                  onPressed: () => _openPage(context, const FeedPage()),
                  icon: const Icon(Icons.dynamic_feed_rounded),
                  label: const Text('Abrir Feed Dinâmico'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
