import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DolarPage extends StatefulWidget {
  const DolarPage({super.key});

  @override
  State<DolarPage> createState() => _DolarPageState();
}

class _DolarPageState extends State<DolarPage> {

  // CONTROLADOR PARA PEGAR O VALOR DIGITADO
  final valorController = TextEditingController();

  // GUARDA O RESULTADO
  String resultado = '';


  // MÉTODO PARA CONSULTAR O DÓLAR
  Future<void> consultarDolar() async {

    try {

      // PEGA O VALOR DIGITADO
      double valor =
          double.parse(
            valorController.text.replaceAll(',', '.'),
          );


      // LINK DA API
      final url = Uri.parse(
        'https://economia.awesomeapi.com.br/last/USD-BRL',
      );


      // FAZ A REQUISIÇÃO
      final resposta = await http.get(url);


      // VERIFICA SE A API FUNCIONOU
      if (resposta.statusCode == 200) {

        // CONVERTE O JSON
        final dados = jsonDecode(resposta.body);


        // PEGA OS DADOS DO DÓLAR
        final dolar = dados['USDBRL'];


        // PEGA O VALOR DE VENDA
        double cotacao =
            double.parse(dolar['ask']);


        // FAZ A CONVERSÃO
        double convertido =
            valor * cotacao;


        // ATUALIZA A TELA
        setState(() {

          resultado =
              'Valor digitado: US\$ ${valor.toStringAsFixed(2)}\n\n'

              'Cotação atual: R\$ ${cotacao.toStringAsFixed(2)}\n\n'

              'Resultado:\n'

              'R\$ ${convertido.toStringAsFixed(2)}';
        });

      } else {

        setState(() {
          resultado =
              'Erro ao consultar a cotação.';
        });

      }

    } catch (erro) {

      setState(() {
        resultado =
            'Digite um valor válido.';
      });

    }
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title:
            const Text('Conversor de Dólar'),

        backgroundColor:
            Colors.deepPurple,

        foregroundColor:
            Colors.white,
      ),


      body: Center(

        child: Padding(

          padding:
              const EdgeInsets.all(20),

          child: Column(

            mainAxisAlignment:
                MainAxisAlignment.center,

            children: [

              const Icon(

                Icons.attach_money,

                size: 100,

                color: Colors.green,
              ),


              const SizedBox(height: 20),


              const Text(

                'Conversor de Dólar',

                style: TextStyle(

                  fontSize: 28,

                  fontWeight:
                      FontWeight.bold,
                ),
              ),


              const SizedBox(height: 30),


              // CAMPO PARA DIGITAR O VALOR

              TextField(

                controller:
                    valorController,

                keyboardType:
                    const TextInputType.numberWithOptions(
                  decimal: true,
                ),

                decoration:
                    const InputDecoration(

                  labelText:
                      'Digite o valor em Dólar (USD)',

                  prefixText:
                      'US\$ ',

                  border:
                      OutlineInputBorder(),
                ),
              ),


              const SizedBox(height: 20),


              // BOTÃO

              SizedBox(

                width: double.infinity,

                child: ElevatedButton(

                  onPressed:
                      consultarDolar,

                  child:
                      const Text(
                    'Converter',
                  ),
                ),
              ),


              const SizedBox(height: 30),


              // RESULTADO

              Text(

                resultado,

                textAlign:
                    TextAlign.center,

                style:
                    const TextStyle(
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  @override
  void dispose() {

    valorController.dispose();

    super.dispose();
  }
}