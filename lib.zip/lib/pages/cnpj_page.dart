import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;


class CnpjPage extends StatefulWidget {

  const CnpjPage({super.key});

  @override
  State<CnpjPage> createState() =>
      _CnpjPageState();
}


class _CnpjPageState extends State<CnpjPage> {


  // Controlador do campo
  final cnpj = TextEditingController();


  // Guarda o resultado
  String empresa = '';


  // Método de consulta
  Future<void> consultar() async {


    // URL da API
    final url = Uri.parse(

      'https://api.opencnpj.org/${cnpj.text}',
    );


    // Faz a requisição
    final resposta = await http.get(url);


    // Converte JSON
    final dados = jsonDecode(resposta.body);


    setState(() {

      // Mostra os dados encontrados.
      // Alguns campos podem variar conforme
      // o retorno da API.

      empresa =

          'CNPJ: ${dados['cnpj'] ?? ''}\n\n'

          'Razão Social: ${dados['razao_social'] ?? ''}\n\n'

          'Nome Fantasia: ${dados['nome_fantasia'] ?? ''}';
    });
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title:
            const Text('Consulta CNPJ'),

        backgroundColor:
            Colors.deepPurple,

        foregroundColor:
            Colors.white,
      ),


      body: Padding(

        padding:
            const EdgeInsets.all(20),

        child: SingleChildScrollView(

          child: Column(

            children: [

              const SizedBox(height: 30),


              const Icon(

                Icons.business,

                size: 100,

                color:
                    Colors.deepPurple,
              ),


              const SizedBox(height: 30),


              TextField(

                controller: cnpj,

                keyboardType:
                    TextInputType.number,

                decoration:
                    const InputDecoration(

                  labelText:
                      'Digite o CNPJ',

                  border:
                      OutlineInputBorder(),
                ),
              ),


              const SizedBox(height: 20),


              ElevatedButton(

                onPressed: consultar,

                child:
                    const Text('Consultar'),
              ),


              const SizedBox(height: 30),


              Text(

                empresa,

                textAlign:
                    TextAlign.center,

                style:
                    const TextStyle(
                  fontSize: 17,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  @override
  void dispose() {

    cnpj.dispose();

    super.dispose();
  }
}