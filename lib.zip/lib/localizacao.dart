import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

/// Tela responsável por obter e exibir a localização atual do aparelho.
class Localizacao extends StatefulWidget {
  const Localizacao({super.key});

  @override
  State<Localizacao> createState() => _LocalizacaoState();
}

class _LocalizacaoState extends State<Localizacao> {
  String latitude = 'Aguardando...';
  String longitude = 'Aguardando...';
  String status = 'Toque no botão para obter sua localização.';
  bool carregando = false;

  /// Verifica se o serviço de localização está ligado e solicita a permissão.
  Future<bool> _verificarPermissao() async {
    final servicoAtivo = await Geolocator.isLocationServiceEnabled();

    if (!servicoAtivo) {
      if (mounted) {
        setState(() {
          status = 'O GPS está desligado. Ative a localização do aparelho.';
        });
      }
      await Geolocator.openLocationSettings();
      return false;
    }

    var permissao = await Geolocator.checkPermission();

    if (permissao == LocationPermission.denied) {
      permissao = await Geolocator.requestPermission();
    }

    if (permissao == LocationPermission.denied) {
      if (mounted) {
        setState(() {
          status = 'Permissão de localização negada.';
        });
      }
      return false;
    }

    if (permissao == LocationPermission.deniedForever) {
      if (mounted) {
        setState(() {
          status = 'Permissão bloqueada. Libere a localização nas configurações.';
        });
      }
      await Geolocator.openAppSettings();
      return false;
    }

    return true;
  }

  /// Obtém a posição atual usando o GPS/localização do aparelho.
  Future<void> buscarLocalizacao() async {
    setState(() {
      carregando = true;
      status = 'Obtendo sua localização...';
    });

    try {
      final permitido = await _verificarPermissao();
      if (!permitido) return;

      final posicao = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      if (!mounted) return;

      setState(() {
        latitude = posicao.latitude.toStringAsFixed(6);
        longitude = posicao.longitude.toStringAsFixed(6);
        status = 'Localização atualizada com sucesso.';
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        status = 'Não foi possível obter a localização.';
      });
    } finally {
      if (mounted) {
        setState(() {
          carregando = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Minha Localização',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color(0xFF502C3E),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.location_on,
                size: 90,
                color: Color(0xFF502C3E),
              ),
              const SizedBox(height: 20),
              const Text(
                'Localização do dispositivo',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                status,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade700,
                ),
              ),
              const SizedBox(height: 30),
              Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _informacao('Latitude', latitude),
                      const Divider(height: 30),
                      _informacao('Longitude', longitude),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 25),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: carregando ? null : buscarLocalizacao,
                  icon: carregando
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.gps_fixed),
                  label: Text(
                    carregando ? 'Obtendo localização...' : 'Obter Localização',
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF502C3E),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _informacao(String titulo, String valor) {
    return Row(
      children: [
        const Icon(Icons.place, color: Color(0xFF502C3E)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                titulo,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                valor,
                style: const TextStyle(fontSize: 17),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
