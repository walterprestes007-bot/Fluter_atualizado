import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

/// Implementação neutra para plataformas que não sejam Android/iOS/web.
class FeedPhotoStore {
  Future<String> saveImage(XFile image) async {
    throw UnsupportedError('O armazenamento de fotos não é suportado nesta plataforma.');
  }

  Future<bool> exists(String path) async => false;

  Widget imageWidget(
    String path, {
    double? width,
    double? height,
    required BoxFit fit,
    required Widget fallback,
  }) => fallback;
}
