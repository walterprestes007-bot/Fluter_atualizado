import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;


class CepPage extends StatefulWidget {

  const CepPage({super.key});

  @override
  State<CepPage> createState() =>
      _CepPageState();
}


class _CepPageState extends State<CepPage> {


  // Controlador do campo CEP
  final cep = TextEditingController();


  // Variável que vai guardar
  // o endereço encontrado
  String endereco = '';


  // Método para consultar o CEP
  Future<void> consultar() async {


    // URL da API ViaCEP
    final url = Uri.parse(

      'https://viacep.com.br/ws/${cep.text}/json/',
    );


    // Faz a requisição para a API
    final resposta = await http.get(url);


    // Converte a resposta JSON
    final dados = jsonDecode(resposta.body);


    // Atualiza a tela
    setState(() {

      endereco =

          'Logradouro: ${dados['logradouro']}\n\n'

          'Bairro: ${dados['bairro']}\n\n'

          'Cidade: ${dados['localidade']}\n\n'

          'Estado: ${dados['uf']}';
    });
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title:
            const Text('Consulta CEP'),

        backgroundColor:
            Colors.deepPurple,

        foregroundColor:
            Colors.white,
      ),


      body: Padding(

        padding:
            const EdgeInsets.all(20),

        child: Column(

          children: [

            const SizedBox(height: 30),


            const Icon(

              Icons.location_on,

              size: 100,

              color:
                  Colors.deepPurple,
            ),


            const SizedBox(height: 30),


            TextField(

              controller: cep,

              keyboardType:
                  TextInputType.number,

              decoration:
                  const InputDecoration(

                labelText:
                    'Digite o CEP',

                border:
                    OutlineInputBorder(),
              ),
            ),


            const SizedBox(height: 20),


            ElevatedButton(

              onPressed: consultar,

              child:
                  const Text('Consultar'),
            ),


            const SizedBox(height: 30),


            Text(

              endereco,

              textAlign:
                  TextAlign.center,

              style:
                  const TextStyle(
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }


  @override
  void dispose() {

    cep.dispose();

    super.dispose();
  }
}