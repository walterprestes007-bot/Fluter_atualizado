import 'package:flutter/material.dart';


class TrabalhoPage extends StatefulWidget {

  const TrabalhoPage({super.key});

  @override
  State<TrabalhoPage> createState() =>
      _TrabalhoPageState();
}


class _TrabalhoPageState
    extends State<TrabalhoPage> {


  // Controla a página atual
  int paginaAtual = 0;


  // Lista das 3 telas
  final List<Widget> paginas = [

    // TELA 1

    const Center(

      child: Text(

        'Início',

        style:
            TextStyle(
          fontSize: 30,
        ),
      ),
    ),


    // TELA 2

    const Center(

      child: Text(

        'Atividades',

        style:
            TextStyle(
          fontSize: 30,
        ),
      ),
    ),


    // TELA 3

    const Center(

      child: Text(

        'Perfil',

        style:
            TextStyle(
          fontSize: 30,
        ),
      ),
    ),
  ];


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title:
            const Text('Trabalho'),

        backgroundColor:
            Colors.deepPurple,

        foregroundColor:
            Colors.white,
      ),


      // Mostra a página selecionada
      body:
          paginas[paginaAtual],


      // Menu inferior
      bottomNavigationBar:

          BottomNavigationBar(

        currentIndex:
            paginaAtual,


        onTap: (index) {

          setState(() {

            paginaAtual = index;

          });
        },


        items: const [

          BottomNavigationBarItem(

            icon:
                Icon(Icons.home),

            label:
                'Início',
          ),


          BottomNavigationBarItem(

            icon:
                Icon(Icons.assignment),

            label:
                'Atividades',
          ),


          BottomNavigationBarItem(

            icon:
                Icon(Icons.person),

            label:
                'Perfil',
          ),
        ],
      ),
    );
  }
}