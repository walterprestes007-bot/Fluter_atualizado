import 'dart:convert';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/feed_photo_store.dart';

/// Feed dinâmico inspirado em redes sociais.
///
/// As publicações criadas pelo usuário são copiadas para a pasta privada
/// documentos/fotos_feed do aplicativo e continuam disponíveis depois de
/// fechar e abrir o app. Os nomes e os dados das publicações também são salvos.
class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  static String? get _postsStorageKey => null;

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  static const String _namesStorageKey = 'feed_names_v1';
  static const String _postsStorageKey = 'feed_local_posts_v1';

  final ImagePicker _imagePicker = ImagePicker();
  final FeedPhotoStore _photoStore = FeedPhotoStore();

  final List<String> _defaultNames = <String>[
    'Aluno do curso',
    'Maria Oliveira',
    'João Pedro',
    'Ana Clara',
    'Lucas Santos',
  ];

  late List<String> _names;
  late List<FeedPost> _posts;
  String? _selectedNameFilter;
  bool _loadingSavedData = true;

  @override
  void initState() {
    super.initState();
    _names = List<String>.from(_defaultNames);
    _posts = _samplePosts();
    _loadSavedData();
  }

  List<FeedPost> _samplePosts() => <FeedPost>[
        FeedPost(
          id: 'sample-1',
          author: 'Aluno do curso',
          imageUrl:
              'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=900',
          caption: 'Um lugar incrível para conhecer! 🌄',
          likes: 12,
        ),
        FeedPost(
          id: 'sample-2',
          author: 'Maria Oliveira',
          imageUrl:
              'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=900',
          caption: 'A natureza sempre surpreende. 🌿',
          likes: 25,
        ),
        FeedPost(
          id: 'sample-3',
          author: 'João Pedro',
          imageUrl:
              'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=900',
          caption: 'Começando o dia com uma paisagem bonita. ☀️',
          likes: 8,
        ),
      ];

  List<FeedPost> get _visiblePosts {
    if (_selectedNameFilter == null) return _posts;
    return _posts
        .where((post) => post.author == _selectedNameFilter)
        .toList();
  }

  Future<void> _loadSavedData() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      final savedNames = preferences.getStringList(_namesStorageKey);
      final savedPostsJson = preferences.getString(_postsStorageKey);
      final localPosts = <FeedPost>[];

      if (savedPostsJson != null && savedPostsJson.isNotEmpty) {
        final decoded = jsonDecode(savedPostsJson);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is! Map) continue;
            final post = FeedPost.fromJson(Map<String, dynamic>.from(item));
            final imagePath = post.imagePath;
            if (imagePath != null && await _photoStore.exists(imagePath)) {
              localPosts.add(post);
            }
          }
        }
      }

      if (!mounted) return;
      setState(() {
        if (savedNames != null && savedNames.isNotEmpty) {
          _names = savedNames.toSet().toList();
        }
        _posts = <FeedPost>[..._samplePosts(), ...localPosts];
        _loadingSavedData = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingSavedData = false);
    }
  }

  Future<void> _saveNames() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setStringList(_namesStorageKey, _names);
  }

  Future<void> _saveLocalPosts() async {
    final preferences = await SharedPreferences.getInstance();
    final localPosts = _posts
        .where((post) => post.imagePath != null)
        .map((post) => post.toJson())
        .toList();
    await preferences.setString(_postsStorageKey, jsonEncode(localPosts));
  }

  Future<void> _addName() async {
    final controller = TextEditingController();
    final newName = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Adicionar nome ao feed'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          maxLength: 40,
          decoration: const InputDecoration(
            labelText: 'Nome da pessoa',
            hintText: 'Ex.: Pedro Souza',
            prefixIcon: Icon(Icons.person_outline),
          ),
          onSubmitted: (value) => Navigator.pop(dialogContext, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text.trim()),
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );
    controller.dispose();

    final name = newName?.trim();
    if (name == null || name.isEmpty || !mounted) return;
    if (_names.any((existing) => existing.toLowerCase() == name.toLowerCase())) {
      _showMessage('Esse nome já está na lista.');
      return;
    }

    setState(() {
      _names.insert(0, name);
      _selectedNameFilter = null;
    });
    await _saveNames();
    _showMessage('$name foi adicionado à lista do feed.');
  }

  Future<void> _showImageSourceOptions() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Wrap(
            children: [
              const ListTile(
                title: Text(
                  'Nova publicação',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                ),
                subtitle: Text('Escolha de onde virá sua foto.'),
              ),
              ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.camera_alt_outlined),
                ),
                title: const Text('Tirar foto'),
                subtitle: const Text('Abrir a câmera do celular'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _chooseImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.photo_library_outlined),
                ),
                title: const Text('Escolher da galeria'),
                subtitle: const Text('Selecionar uma foto já existente'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _chooseImage(ImageSource.gallery);
                },
              ),
              ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.folder_open_outlined),
                ),
                title: const Text('Abrir pasta interna'),
                subtitle: const Text('Ver as fotos salvas neste aplicativo'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _openInternalFolder();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _chooseImage(ImageSource source) async {
    try {
      final image = await _imagePicker.pickImage(
        source: source,
        imageQuality: 90,
      );
      if (image == null || !mounted) return;

      final draft = await _askForPostDetails();
      if (draft == null || !mounted) return;

      final savedImagePath = await _photoStore.saveImage(image);

      final post = FeedPost(
        id: 'local-${DateTime.now().microsecondsSinceEpoch}',
        author: draft.author,
        imagePath: savedImagePath,
        caption: draft.caption,
        likes: 0,
      );

      if (!mounted) return;
      setState(() {
        _posts.insert(0, post);
        _selectedNameFilter = null;
      });
      await _saveLocalPosts();
      _showMessage('Foto publicada e salva na pasta interna do aplicativo.');
    } on CameraException catch (error) {
      if (mounted) {
        _showMessage('Não foi possível usar a câmera: ${error.description ?? error.code}');
      }
    } catch (_) {
      if (mounted) {
        _showMessage('Não foi possível salvar a foto. Verifique as permissões e tente novamente.');
      }
    }
  }

  Future<_PostDraft?> _askForPostDetails() async {
    final captionController = TextEditingController();
    String selectedAuthor = _names.isNotEmpty ? _names.first : 'Aluno do curso';

    final result = await showDialog<_PostDraft>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Preparar publicação'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedAuthor,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Publicar como',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                  items: _names
                      .map((name) => DropdownMenuItem<String>(
                            value: name,
                            child: Text(name, overflow: TextOverflow.ellipsis),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => selectedAuthor = value);
                    }
                  },
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: captionController,
                  maxLines: 3,
                  maxLength: 180,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(
                    labelText: 'Legenda (opcional)',
                    hintText: 'Escreva algo sobre a foto...',
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'A imagem será copiada para a pasta privada do app.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.pop(
                dialogContext,
                _PostDraft(
                  author: selectedAuthor,
                  caption: captionController.text.trim(),
                ),
              ),
              icon: const Icon(Icons.publish_rounded),
              label: const Text('Publicar'),
            ),
          ],
        ),
      ),
    );
    captionController.dispose();
    return result;
  }

  Future<void> _openInternalFolder() async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(builder: (_) => const InternalPhotosPage()),
    );
  }

  void _toggleLike(FeedPost post) {
    setState(() {
      post.liked = !post.liked;
      post.likes += post.liked ? 1 : -1;
      if (post.likes < 0) post.likes = 0;
    });
    if (post.imagePath != null) _saveLocalPosts();
  }

  Future<void> _openComments(FeedPost post) async {
    final controller = TextEditingController();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            18,
            4,
            18,
            MediaQuery.of(sheetContext).viewInsets.bottom + 18,
          ),
          child: StatefulBuilder(
            builder: (context, setSheetState) => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Comentários',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                if (post.comments.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 18),
                    child: Text('Ainda não há comentários. Seja o primeiro!'),
                  )
                else
                  ...post.comments.map(
                    (comment) => ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const CircleAvatar(
                        radius: 16,
                        child: Icon(Icons.person, size: 18),
                      ),
                      title: Text(comment),
                    ),
                  ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        autofocus: true,
                        maxLength: 180,
                        decoration: const InputDecoration(
                          hintText: 'Adicione um comentário...',
                          border: OutlineInputBorder(),
                          counterText: '',
                        ),
                        onSubmitted: (_) => _addComment(
                          post,
                          controller,
                          setSheetState,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      tooltip: 'Enviar comentário',
                      onPressed: () => _addComment(
                        post,
                        controller,
                        setSheetState,
                      ),
                      icon: const Icon(Icons.send_rounded),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    controller.dispose();
  }

  void _addComment(
    FeedPost post,
    TextEditingController controller,
    StateSetter setSheetState,
  ) {
    final value = controller.text.trim();
    if (value.isEmpty) return;
    setState(() => post.comments.add(value));
    setSheetState(() {});
    controller.clear();
    if (post.imagePath != null) _saveLocalPosts();
  }

  Future<void> _sharePost(FeedPost post) async {
    final details = '${post.author} publicou no Meu Feed: ${post.caption}';
    await Clipboard.setData(ClipboardData(text: details.trim()));
    if (mounted) _showMessage('Resumo da publicação copiado para compartilhar.');
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final visiblePosts = _visiblePosts;

    return Scaffold(
      backgroundColor: const Color(0xFFF7F5FC),
      appBar: AppBar(
        title: const Text(
          'Meu Feed',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'Adicionar nome',
            onPressed: _addName,
            icon: const Icon(Icons.person_add_alt_1_rounded),
          ),
          IconButton(
            tooltip: 'Pasta interna de fotos',
            onPressed: _openInternalFolder,
            icon: const Icon(Icons.folder_open_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showImageSourceOptions,
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_a_photo_outlined),
        label: const Text('Publicar'),
      ),
      body: RefreshIndicator(
        onRefresh: _loadSavedData,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildStories()),
            SliverToBoxAdapter(child: _buildCreatePostCard()),
            if (_selectedNameFilter != null)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Publicações de $_selectedNameFilter',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                      TextButton(
                        onPressed: () => setState(() => _selectedNameFilter = null),
                        child: const Text('Ver todos'),
                      ),
                    ],
                  ),
                ),
              ),
            if (_loadingSavedData)
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                ),
              )
            else if (visiblePosts.isEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(28, 28, 28, 110),
                  child: Column(
                    children: [
                      Icon(Icons.photo_library_outlined,
                          size: 54, color: Colors.deepPurple.shade200),
                      const SizedBox(height: 12),
                      const Text(
                        'Ainda não há publicações dessa pessoa.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      const Text('Escolha outro nome ou adicione uma foto ao feed.'),
                    ],
                  ),
                ),
              )
            else
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _buildPostCard(visiblePosts[index]),
                  childCount: visiblePosts.length,
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 92)),
          ],
        ),
      ),
    );
  }

  Widget _buildStories() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 14, 12, 10),
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
      ),
      child: SizedBox(
        height: 98,
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          scrollDirection: Axis.horizontal,
          itemCount: _names.length + 1,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (context, index) {
            if (index == 0) {
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _addName,
                child: SizedBox(
                  width: 66,
                  child: Column(
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          color: Colors.deepPurple.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.person_add_alt_1,
                            color: Colors.deepPurple, size: 28),
                      ),
                      const SizedBox(height: 6),
                      const Text('Adicionar',
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 11)),
                    ],
                  ),
                ),
              );
            }

            final name = _names[index - 1];
            final isSelected = _selectedNameFilter == name;
            final hasPosts = _posts.any((post) => post.author == name);
            final colors = <Color>[
              Colors.deepPurple,
              Colors.teal,
              Colors.orange,
              Colors.pink,
              Colors.indigo,
            ];
            final color = colors[(index - 1) % colors.length];

            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => setState(() {
                _selectedNameFilter = isSelected ? null : name;
              }),
              child: SizedBox(
                width: 70,
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isSelected || hasPosts
                              ? color
                              : Colors.grey.shade300,
                          width: isSelected ? 3 : 2,
                        ),
                      ),
                      child: CircleAvatar(
                        radius: 25,
                        backgroundColor: color.withValues(alpha: 0.12),
                        child: Text(
                          _initials(name),
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      name.split(' ').first,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildCreatePostCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          const CircleAvatar(
            backgroundColor: Color(0xFFEDE7F6),
            child: Icon(Icons.person, color: Colors.deepPurple),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: _showImageSourceOptions,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F5FC),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.deepPurple.shade50),
                ),
                child: const Text('Compartilhe uma foto...'),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Adicionar foto',
            onPressed: _showImageSourceOptions,
            color: Colors.deepPurple,
            icon: const Icon(Icons.photo_camera_back_outlined),
          ),
        ],
      ),
    );
  }

  Widget _buildPostCard(FeedPost post) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.deepPurple.withValues(alpha: 0.045),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            contentPadding: const EdgeInsets.fromLTRB(14, 4, 8, 4),
            leading: CircleAvatar(
              backgroundColor: Colors.deepPurple.shade50,
              child: Text(
                _initials(post.author),
                style: const TextStyle(
                  color: Colors.deepPurple,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            title: Text(post.author,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(post.imagePath != null ? 'Foto salva neste dispositivo' : 'Publicação do feed'),
            trailing: PopupMenuButton<String>(
              tooltip: 'Opções da publicação',
              onSelected: (value) {
                if (value == 'share') _sharePost(post);
                if (value == 'filter') {
                  setState(() => _selectedNameFilter = post.author);
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'share', child: Text('Copiar para compartilhar')),
                PopupMenuItem(value: 'filter', child: Text('Ver publicações desta pessoa')),
              ],
            ),
          ),
          _buildPostImage(post),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
            child: Row(
              children: [
                IconButton(
                  tooltip: post.liked ? 'Descurtir' : 'Curtir',
                  onPressed: () => _toggleLike(post),
                  icon: Icon(
                    post.liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: post.liked ? Colors.redAccent : Colors.black87,
                    size: 28,
                  ),
                ),
                IconButton(
                  tooltip: 'Comentar',
                  onPressed: () => _openComments(post),
                  icon: const Icon(Icons.mode_comment_outlined, size: 26),
                ),
                IconButton(
                  tooltip: 'Compartilhar',
                  onPressed: () => _sharePost(post),
                  icon: const Icon(Icons.send_outlined, size: 25),
                ),
                const Spacer(),
                if (post.imagePath != null)
                  const Padding(
                    padding: EdgeInsets.only(right: 12),
                    child: Icon(Icons.folder_copy_outlined,
                        color: Colors.deepPurple, size: 20),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: Text(
              '${post.likes} curtida${post.likes == 1 ? '' : 's'}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          if (post.caption.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 8),
              child: Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: '${post.author} ',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    TextSpan(text: post.caption),
                  ],
                ),
              ),
            ),
          if (post.comments.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: InkWell(
                onTap: () => _openComments(post),
                child: Text(
                  'Ver ${post.comments.length} comentário${post.comments.length == 1 ? '' : 's'}',
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ),
            )
          else
            const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _buildPostImage(FeedPost post) {
    if (post.imagePath != null) {
      return _photoStore.imageWidget(
        post.imagePath!,
        width: double.infinity,
        height: 285,
        fit: BoxFit.cover,
        fallback: _imageErrorPlaceholder(),
      );
    }

    return Image.network(
      post.imageUrl!,
      width: double.infinity,
      height: 285,
      fit: BoxFit.cover,
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) return child;
        return Container(
          height: 285,
          color: Colors.deepPurple.shade50,
          child: const Center(child: CircularProgressIndicator()),
        );
      },
      errorBuilder: (_, __, ___) => _imageErrorPlaceholder(),
    );
  }

  Widget _imageErrorPlaceholder() => Container(
        height: 285,
        color: Colors.deepPurple.shade50,
        alignment: Alignment.center,
        child: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.broken_image_outlined, size: 48, color: Colors.deepPurple),
            SizedBox(height: 8),
            Text('Não foi possível carregar esta imagem.'),
          ],
        ),
      );

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+')).where((part) => part.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return '${parts.first.substring(0, 1)}${parts.last.substring(0, 1)}'.toUpperCase();
  }
}

class _PostDraft {
  const _PostDraft({required this.author, required this.caption});

  final String author;
  final String caption;
}

/// Tela de arquivos gravados na pasta interna documentos/fotos_feed.
class InternalPhotosPage extends StatefulWidget {
  const InternalPhotosPage({super.key});

  @override
  State<InternalPhotosPage> createState() => _InternalPhotosPageState();
}

class _InternalPhotosPageState extends State<InternalPhotosPage> {
  final FeedPhotoStore _photoStore = FeedPhotoStore();
  List<String> _photos = <String>[];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPhotos();
  }

  Future<void> _loadPhotos() async {
    try {
      final preferences = await SharedPreferences.getInstance();
        final savedPostsJson =
          preferences.getString(_FeedPageState._postsStorageKey) ?? '';
      final photos = <String>[];

      if (savedPostsJson != null && savedPostsJson.isNotEmpty) {
        final decoded = jsonDecode(savedPostsJson);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is! Map) continue;
            final post = FeedPost.fromJson(Map<String, dynamic>.from(item));
            final path = post.imagePath;
            if (path != null && await _photoStore.exists(path)) {
              photos.add(path);
            }
          }
        }
      }

      if (mounted) setState(() { _photos = photos; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _openPhoto(String path) {
    Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            title: const Text('Foto salva'),
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
          ),
          body: Center(
            child: InteractiveViewer(
              child: _photoStore.imageWidget(
                path,
                fit: BoxFit.contain,
                fallback: const Text(
                  'Não foi possível abrir esta imagem.',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F5FC),
      appBar: AppBar(
        title: const Text('Pasta interna de fotos'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _photos.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.folder_open_rounded,
                            size: 68, color: Colors.deepPurple.shade200),
                        const SizedBox(height: 14),
                        const Text(
                          'Sua pasta ainda está vazia',
                          style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Publique uma foto usando a câmera ou a galeria. Ela será salva aqui, dentro do aplicativo.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadPhotos,
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    physics: const AlwaysScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: _photos.length,
                    itemBuilder: (context, index) => InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => _openPhoto(_photos[index]),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: _photoStore.imageWidget(
                          _photos[index],
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                          fallback: Container(
                            color: Colors.deepPurple.shade50,
                            child: const Icon(Icons.broken_image_outlined),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
    );
  }
}

class FeedPost {
  FeedPost({
    required this.id,
    required this.author,
    this.imageUrl,
    this.imagePath,
    this.caption = '',
    this.likes = 0,
    this.liked = false,
    List<String>? comments,
  }) : comments = comments ?? <String>[];

  final String id;
  final String author;
  final String? imageUrl;
  final String? imagePath;
  final String caption;
  int likes;
  bool liked;
  final List<String> comments;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'author': author,
        'imagePath': imagePath,
        'caption': caption,
        'likes': likes,
        'liked': liked,
        'comments': comments,
      };

  factory FeedPost.fromJson(Map<String, dynamic> json) => FeedPost(
        id: json['id']?.toString() ?? 'local-${DateTime.now().microsecondsSinceEpoch}',
        author: json['author']?.toString() ?? 'Aluno do curso',
        imagePath: json['imagePath']?.toString(),
        caption: json['caption']?.toString() ?? '',
        likes: json['likes'] is int ? json['likes'] as int : 0,
        liked: json['liked'] == true,
        comments: (json['comments'] as List<dynamic>? ?? <dynamic>[])
            .map((comment) => comment.toString())
            .toList(),
      );
}
