import 'package:flutter/material.dart';
import 'login_page.dart';

class InicialPage extends StatelessWidget {
  const InicialPage({super.key});

  // MÉTODO PARA IR PARA A TELA DE LOGIN
  void irParaLogin(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const LoginPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            // ÍCONE CLICÁVEL
            IconButton(
              iconSize: 120,

              icon: const Icon(
                Icons.search,
                color: Colors.white,
              ),

              onPressed: () {
                irParaLogin(context);
              },
            ),

            const SizedBox(height: 20),

            const Text(
              'Consulta Fácil',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),

            const SizedBox(height: 10),

            const Text(
              'Consulte CEP, CNPJ e Dólar',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white,
              ),
            ),

            const SizedBox(height: 40),

            // BOTÃO PARA IR AO LOGIN
            ElevatedButton(
              onPressed: () {
                irParaLogin(context);
              },

              child: const Text(
                'Entrar',
              ),
            ),
          ],
        ),
      ),
    );
  }
}